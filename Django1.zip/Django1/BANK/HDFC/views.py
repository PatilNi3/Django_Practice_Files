from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def show(r):
    return HttpResponse('<h1> This is from Django Server. '
                        'Inside BANK Project, HDFC Application. </h1>')
def display(r):
    return HttpResponse('<h1> This is from Django Server. '
                        'In BANK Project, HDFC Application, Home Loan Department. </h1>')
def visual(r):
    return HttpResponse('<h1> This is from Django Server. '
                        'In BANK Project, HDFC Application, Vehicle Loan Department. </h1>')