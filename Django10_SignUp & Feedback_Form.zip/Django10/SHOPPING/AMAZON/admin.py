from django.contrib import admin
from .models import FeedbackModel

# Register your models here.
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ['Name' ,'Age' ,'Email', 'Feedback']

admin.site.register(FeedbackModel, FeedbackAdmin)