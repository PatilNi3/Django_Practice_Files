from django.shortcuts import render
from .models import FeedbackModel
from .forms import FeedbackForm, SignUpForm
from django.http import HttpResponseRedirect

# Create your views here.
def home(r):
    return render(r, 'Electronics/Home.html')

def electronics(r):
    return render(r, 'Electronics/Electronics.html')

def sony(r):
    return render(r, 'Electronics/Sony.html')

def samsung(r):
    return render(r, 'Electronics/Samsung.html')

def lg(r):
    return render(r, 'Electronics/LG.html')

def feedback(r):
    form = FeedbackForm
    if r.method == 'POST':
        form = FeedbackForm(r.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/')
    return render(r, 'Electronics/Feedback.html', {'form':form})

def signup(r):
    form = SignUpForm
    if r.method == 'POST':
        form = SignUpForm(r.POST)
        user = form.save()
        user.set_password(user.password)
        user.save()
        return HttpResponseRedirect('/')

    return render(r, 'Electronics/SignUp.html', {'form':form})