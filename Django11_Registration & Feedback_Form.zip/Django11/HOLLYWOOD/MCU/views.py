from django.shortcuts import render
from .models import FeedbackModel
from .forms import FeedbackForm
from django.http import HttpResponseRedirect
from django.contrib.auth.decorators import login_required

# Create your views here.
def home(r):
    return render(r, 'Mcu/Home.html')

def mcu(r):
    return render(r, 'Mcu/MCU.html')

def other(r):
    return render(r, 'Mcu/Other.html')

def iron_man(r):
    return render(r, 'Mcu/Iron Man.html')

def captain_america(r):
    return render(r, 'Mcu/Captain America.html')

def thor(r):
    return render(r, 'Mcu/Thor.html')

def dr_strange(r):
    return render(r, 'Mcu/Dr Strange.html')

def black_panther(r):
    return render(r,'Mcu/Black Panther.html')

def more(r):
    return render(r, 'Mcu/More.html')

@ login_required
def feedback(r):
    form = FeedbackForm
    if r.method == 'POST':
        form = FeedbackForm(r.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/')
    return render(r, 'Mcu/Feedback.html', {'form':form})


