from django.contrib import admin
from .models import Books

# Register your models here.
class BooksAdmin(admin.ModelAdmin):
    list_display = ['Book_Name', 'Moto', 'Author', 'Publish_Date', 'Pages']

admin.site.register(Books, BooksAdmin)