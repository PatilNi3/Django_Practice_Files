from django.db import models

# Create your models here.
class Books(models.Model):
    Book_Name = models.CharField(max_length=100)
    Moto = models.CharField(max_length=100)
    Author = models.CharField(max_length=50)
    Publish_Date = models.DateField()
    Pages = models.IntegerField()
