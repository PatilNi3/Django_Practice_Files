from django.shortcuts import render
from .models import Books

# Create your views here.
def books_views(r):
    Book_list = Books.objects.all()             # ORM (Object Relational Mapping) Query

    # ORM (Object Relational Mapping) Query
    Book_list = Books.objects.filter(Pages__gt=200)                     # gt=greater than
    Book_list = Books.objects.filter(Pages__lt=200)                     # lt=less than
    Book_list = Books.objects.filter(Pages__exact=198)                  # exact=exact pages
    Book_list = Books.objects.filter(Publish_Date__gte='2006-11-26')    # gte=greater than or equalto
    Book_list = Books.objects.filter(Publish_Date__lte='2006-11-26')    # lte=less than or equalto
    Book_list = Books.objects.filter(Publish_Date__exact='2006-11-26')  # exact=exact date
    Book_list = Books.objects.filter(Book_Name__exact='The Intelligent Investor')     # exact=exact name
    Book_list = Books.objects.filter(Book_Name__exact='the intelligent investor')     # Still Working
    Book_List = Books.objects.filter(Book_Name__startswith='T')
    Book_List = Books.objects.filter(Book_Name__startswith = 't')       # Still Working
    Book_List = Books.objects.filter(Book_Name__istartswith='r')        # in-case sensitive
    Book_List = Books.objects.filter(Book_Name__startswith='N')         # No Record Found
    Book_List = Books.objects.filter(Book_Name__endswith='t')           # Not Working
    Book_List = Books.objects.filter(Book_Name__endswith='T')           # case sensitive # Not Working
    Book_List = Books.objects.filter(Book_Name__iendswith='t')          # Not Working
    Book_List = Books.objects.filter(Book_Name__iendswith='T')          # Not Working

    # MULTIPLE QUERIES
    Book_List = Books.objects.filter(Book_Name__iendswith='T') | Books.objects.filter(Pages__gte=500)
    Book_List = Books.objects.filter(Book_Name__iendswith='t') | Books.objects.filter(Pages__gte=1000)
    Book_List = Books.objects.filter(Book_Name__iendswith='n') | Books.objects.filter(Pages__gte=1000)  # No Record Found

    # from django.db import Q
    Book_List = Books.objects.filter(Q(Book_Name__iendswith='n') | Q(Pages__gte=1000))                  # No Record Found
    Book_List = Books.objects.filter(Q(Book_Name__iendswith='t') & Q(Pages__exact=198))

    # NOT or EXCLUDE
    Book_List = Books.objects.filter(~(Q(Book_Name__iendswith='t') & Q(Pages__exact=198)))
    Book_List = Books.objects.exclude(Pages__exact=198)
    Book_List = Books.objects.exclude(Q(Book_Name__iendswith='t') & Q(Pages__exact=198))
    Book_List = Books.objects.exclude(~(Q(Book_Name__iendswith='t') & Q(Pages__exact=198)))

    # TABLE CONTENT
    Book_List = Books.objects.values('Book_Name', 'Purpose', 'Author')

    # ORDERING (ASCENDING and DESCENDING)
    Book_List = Books.objects.all().order_by('Pages')              # by default ascending order
    Book_List = Books.objects.all().order_by('-Pages')
    Book_List = Books.objects.all().order_by('Book_Name')
    Book_List = Books.objects.all().order_by('Publish_Date')
    Book_List = Books.objects.all().order_by('Publish_Date')[0:2]  # To get first two records

    Book_Dict = {'BookDict':Book_list}
    return render(r, 'Books/Books.html', context=Book_Dict)