from django.contrib import admin
from .models import Crud_Model

# Register your models here.
class Crud_Admin(admin.ModelAdmin):
    list_display = ['Name', 'Age', 'DOB', 'Email']

admin.site.register(Crud_Model, Crud_Admin)