from django import forms
from .models import Crud_Model

class Crud_Form(forms.ModelForm):
    class Meta:
        model = Crud_Model
        fields = '__all__'