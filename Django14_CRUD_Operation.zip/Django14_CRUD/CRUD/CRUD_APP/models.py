from django.db import models

# Create your models here.
class Crud_Model(models.Model):
    Name = models.CharField(max_length=100)
    Age = models.IntegerField()
    DOB = models.DateField()
    Email = models.EmailField()