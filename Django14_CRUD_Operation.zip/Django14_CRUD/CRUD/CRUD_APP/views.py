from django.shortcuts import render
from .models import Crud_Model
from .forms import Crud_Form
from django.http import HttpResponseRedirect

# Create your views here.
def crud_views(r):
    Crud_list = Crud_Model.objects.all()
    return render(r, 'Index.html', {'CrudDict':Crud_list})

def create(r):
    form = Crud_Form
    if r.method == 'POST':
        form = Crud_Form(r.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/')
    return render(r, 'Create.html', {'form':form})

def delete(r, id):
    Crud_Delete = Crud_Model.objects.get(id=id)
    Crud_Delete.delete()
    return HttpResponseRedirect('/')

def update(r, id):
    Crud_Update = Crud_Model.objects.get(id=id)
    if r.method == 'POST':
        Crud_Up = Crud_Form(r.POST, instance=Crud_Update)
        if Crud_Up.is_valid():
            Crud_Up.save()
            return HttpResponseRedirect('/')
    return render(r, 'Update.html', {'CrudUpdate':Crud_Update})