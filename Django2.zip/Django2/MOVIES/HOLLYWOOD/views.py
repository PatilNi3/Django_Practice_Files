from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def h_movies(r):
    return HttpResponse ('<h1> This is from Django Server. '
                         'MCU Series from Hollywood. </h1>')