from django.apps import AppConfig


class CivilConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'CIVIL'
