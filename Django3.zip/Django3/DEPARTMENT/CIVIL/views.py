from django.shortcuts import render

# Create your views here.
def flat(r):
    return render(r, 'Construct/Flat.html')