from django.shortcuts import render

# Create your views here.
def merc(r):
    return render(r, 'Design/Mercedes.html')
