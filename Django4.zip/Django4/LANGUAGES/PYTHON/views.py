from django.shortcuts import render

# Create your views here.
def p_basic(r):
    Basic = {
        'Data_Structures''' : ['List', 'Tuple', 'String', 'Set', 'Dictionary', 'Frozenset'],
        'Typecasting' : ['into int', 'into float', 'int str', 'into list', 'into tuple'],
        'Conditional_Statement' : ['simple if', 'if-else', 'if-elif-else', 'if-elif-else ladder', 'nested if-else'],
        'Looping_Statement' : ["for loop", "while loop"],
        'Comprehension' : ['List Comprehension', 'Tuple Comprehension', 'Set Comprehension', 'Generator Comprehension']
    }
    return render(r, 'Python/Basic_Python.html', context= Basic)

def p_advance(r):
    Advance = {
        'OOPs' : ['Class & Object', 'Inheritance', 'Polymorphism', 'Abstraction', 'Encapsulation'],
        'Class_Object' : ['class', 'object of class', 'methods', 'variables'],
        'Inheritance' : ['Single level', 'Multi level', 'Multiple', 'Hierarchical', 'Hybrid']
    }
    return render(r, 'Python/Advanced_Python.html', context= Advance)