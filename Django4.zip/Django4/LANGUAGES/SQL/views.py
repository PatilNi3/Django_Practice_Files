from django.shortcuts import render

# Create your views here.
def s_clauses(r):
    clause = {
        'where_clause' : ['Comparitive Operator', 'Logical Operator', 'In/not In Operator', 'Between/not between Operator' 'Like Operator', 'Arithmetic Operator'],
        'order_by_clause' : ['Ascending', 'Descending']
    }
    return render(r, 'Sql/Clauses.html', context= clause)

def s_joins(r):
    join = {
        'Inner_Join' : 'Inner Join',
        'Outer_Join' : ['Left Outer Join', 'Right Outer Join', 'Full Outer Join'],
        'Equi_Join' : 'similar to inner join',
        'Cross_Join' : 'do not check common records',
        'Self_Join' : 'applying join on single table'
    }
    return render(r, 'Sql/Joins.html', context= join)