from django.shortcuts import render

# Create your views here.
def mm(r):
    suv = {
        'Brand' : 'Mahindra & Mahindra',
        'Varient' : 'XUV 700',
        'Price' : '22 Lakh'
    }
    return render(r, 'Mahindra/Suv.html', context= suv)