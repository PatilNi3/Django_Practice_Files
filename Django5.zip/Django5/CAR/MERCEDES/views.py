from django.shortcuts import render

# Create your views here.
def merc(r):
    sedan = {
        'Brand' : 'Mercedes Benz',
        'Varient' : 'C-Class',
        'Price' : '61 Lakh'
    }
    return render(r, 'Mercedes/Sedan.html', context= sedan)