create table Django6_Table (ID int, Name varchar(15), City varchar (15), Sal int)

insert into Django6_Table values (1, 'Nitin Patil', 'Banglore', 150000)

select * from Django6_Table

select * from dbo.ANDROID_budget_friendly