from django.apps import AppConfig


class AndroidConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ANDROID'
