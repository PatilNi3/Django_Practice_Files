from django.db import models

# Create your models here.
class budget_friendly(models.Model):
    Name = models.CharField(max_length=25)
    DOB = models.DateField()
    Salary = models.IntegerField()
    Email = models.EmailField()