from django.contrib import admin
from .models import Gaming

# Register your models here.
class Admin_Gaming(admin.ModelAdmin):
    list_display = ['Name', 'Model', 'Price', 'Email', 'Date']

admin.site.register(Gaming, Admin_Gaming)