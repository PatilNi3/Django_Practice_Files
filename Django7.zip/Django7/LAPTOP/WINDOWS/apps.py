from django.apps import AppConfig


class WindowsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'WINDOWS'
