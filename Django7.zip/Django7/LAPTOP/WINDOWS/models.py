from django.db import models

# Create your models here.
class Gaming(models.Model):
    Name = models.CharField(max_length= 50)
    Model = models.CharField(max_length= 50)
    Price = models.IntegerField()
    Email = models.EmailField()
    Date = models.DateField(auto_now=True)