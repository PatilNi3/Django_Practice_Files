from django.contrib import admin
from .models import Hollywood_Movies

# Register your models here.
class Admin_Hollywood_Movies(admin.ModelAdmin):
    list_display = ['Movie_Name', 'Year', 'Director_Name', 'Genre', 'Length', 'IMDb_Ratings']

admin.site.register(Hollywood_Movies, Admin_Hollywood_Movies)