from django.db import models

# Create your models here.
class Hollywood_Movies(models.Model):
    Movie_Name = models.CharField(max_length=100)
    Year = models.IntegerField()
    Director_Name = models.CharField(max_length=100)
    Genre = models.CharField(max_length=100)
    Length = models.CharField(max_length=50)
    IMDb_Ratings = models.IntegerField()

