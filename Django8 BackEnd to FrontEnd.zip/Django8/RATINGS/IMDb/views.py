from django.shortcuts import render
from .models import Hollywood_Movies

# Create your views here.
def views_hollywood_movies(r):
    Movie_list = Hollywood_Movies.objects.all()
    Movie_dict = {'MovieDict' : Movie_list}
    return render(r, 'Hollywood/Hollywood_list.html', context= Movie_dict)